package com.example.myvpn

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Random

class MainActivity : AppCompatActivity() {
    private lateinit var btnConnect: ImageView
    private lateinit var ivPowerIcon: ImageView
    private lateinit var tvButtonText: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvTimer: TextView
    private lateinit var tvTitle: TextView
    private lateinit var tvIp: TextView
    private lateinit var tvProtocol: TextView
    private lateinit var tvDownload: TextView
    private lateinit var tvUpload: TextView
    
    private var isVpnRunning = false
    private var secondsElapsed = 0
    
    // ТВОЙ СЕРВЕР
    private val vlessConfig = "vless://d86e6fda-e519-46ab-98eb-9ff9a9da5984@5.83.129.236:443?type=grpc&security=tls&sni=host-de-upscale.cdn.cachefleet.com&serviceName=a9w9wmko0k2od14hv8v&fp=qq#Germany"
    
    private val handler = Handler(Looper.getMainLooper())
    private var pulseAnimator: ObjectAnimator? = null
    private val random = Random()

    private val vpnPermissionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) startVpnService()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnConnect = findViewById(R.id.btnConnect)
        ivPowerIcon = findViewById(R.id.ivPowerIcon)
        tvButtonText = findViewById(R.id.tvButtonText)
        tvStatus = findViewById(R.id.tvStatus)
        tvTimer = findViewById(R.id.tvTimer)
        tvTitle = findViewById(R.id.tvTitle)
        tvIp = findViewById(R.id.tvIp)
        tvProtocol = findViewById(R.id.tvProtocol)
        tvDownload = findViewById(R.id.tvDownload)
        tvUpload = findViewById(R.id.tvUpload)

        btnConnect.setOnClickListener {
            if (!isVpnRunning) {
                val prepareIntent = VpnService.prepare(this)
                if (prepareIntent != null) vpnPermissionLauncher.launch(prepareIntent)
                else startVpnService()
            } else stopVpnService()
        }

        tvTitle.setOnLongClickListener { startActivity(Intent(this, AdminActivity::class.java)); true }
    }

    private fun startVpnService() {
        val intent = Intent(this, MyVpnService::class.java).apply {
            action = MyVpnService.ACTION_CONNECT
            putExtra("VLESS_CONFIG", vlessConfig)
        }
        ContextCompat.startForegroundService(this, intent)
        updateUI(true)
        handler.post(timerRunnable)
        startPulse()
        handler.post(speedRunnable)
    }

    private fun stopVpnService() {
        startService(Intent(this, MyVpnService::class.java).apply { action = MyVpnService.ACTION_DISCONNECT })
        updateUI(false)
        handler.removeCallbacks(timerRunnable)
        stopPulse()
        handler.removeCallbacks(speedRunnable)
    }

    private fun updateUI(connected: Boolean) {
        isVpnRunning = connected
        if (connected) {
            tvButtonText.text = "ЗАЩИЩЕНО"
            tvButtonText.setTextColor(ContextCompat.getColor(this, R.color.bg_dark))
            ivPowerIcon.alpha = 1.0f
            ivPowerIcon.setColorFilter(ContextCompat.getColor(this, R.color.bg_dark))
            tvStatus.text = "СИСТЕМА ЗАЩИЩЕНА"
            tvIp.text = "IP: 5.83.129.236"
            tvProtocol.text = "PROTOCOL: VLESS"
            btnConnect.setBackgroundResource(R.drawable.bg_btn_on)
        } else {
            tvButtonText.text = "ВКЛЮЧИТЬ"
            tvButtonText.setTextColor(ContextCompat.getColor(this, R.color.text_primary))
            ivPowerIcon.alpha = 0.4f
            ivPowerIcon.setColorFilter(ContextCompat.getColor(this, R.color.text_primary))
            tvStatus.text = "СИСТЕМА НЕ ЗАЩИЩЕНА"
            tvIp.text = "IP: 0.0.0.0"
            tvProtocol.text = "PROTOCOL: NONE"
            btnConnect.setBackgroundResource(R.drawable.bg_btn_off)
            tvTimer.text = "00:00:00"
            tvDownload.text = "⬇ 0.0 Mbps"
            tvUpload.text = "⬆ 0.0 Mbps"
        }
    }

    private val speedRunnable = object : Runnable {
        override fun run() {
            if (isVpnRunning) {
                tvDownload.text = String.format("⬇ %.1f Mbps", 15.0 + random.nextDouble() * 85.0)
                tvUpload.text = String.format("⬆ %.1f Mbps", 2.0 + random.nextDouble() * 15.0)
                handler.postDelayed(this, 1000)
            }
        }
    }

    private fun startPulse() {
        pulseAnimator = ObjectAnimator.ofPropertyValuesHolder(btnConnect, PropertyValuesHolder.ofFloat("scaleX", 1.0f, 1.03f), PropertyValuesHolder.ofFloat("scaleY", 1.0f, 1.03f)).apply {
            duration = 1500; repeatCount = ObjectAnimator.INFINITE; repeatMode = ObjectAnimator.REVERSE
        }
        pulseAnimator?.start()
    }

    private fun stopPulse() { pulseAnimator?.cancel(); btnConnect.scaleX = 1.0f; btnConnect.scaleY = 1.0f }

    private val timerRunnable = object : Runnable {
        override fun run() {
            secondsElapsed++
            tvTimer.text = String.format("%02d:%02d:%02d", secondsElapsed / 3600, (secondsElapsed % 3600) / 60, secondsElapsed % 60)
            handler.postDelayed(this, 1000)
        }
    }
}
