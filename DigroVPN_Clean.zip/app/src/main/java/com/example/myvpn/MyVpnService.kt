package com.example.myvpn

import android.app.*
import android.content.Intent
import android.net.VpnService
import android.os.Build
import androidx.core.app.NotificationCompat
import dev.dev7.lib.v2ray.V2rayController

class MyVpnService : VpnService() {
    companion object {
        const val ACTION_CONNECT = "com.example.myvpn.CONNECT"
        const val ACTION_DISCONNECT = "com.example.myvpn.DISCONNECT"
        private const val CHANNEL_ID = "vpn_channel"
        private const val NOTIFICATION_ID = 1
    }

    override fun onCreate() {
        super.onCreate()
        V2rayController.init(this, android.R.drawable.ic_lock_lock, "DigroVPN")
        val channel = NotificationChannel(CHANNEL_ID, "VPN", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val config = intent.getStringExtra("VLESS_CONFIG")
                if (config != null) {
                    startForeground(NOTIFICATION_ID, buildNotification())
                    LogManager.addLog("Service: Подключение...")
                    try {
                        V2rayController.startV2ray(this, "DigroVPN Server", config, null)
                        LogManager.addLog("Service: Xray запущен!")
                    } catch (e: Exception) {
                        LogManager.addLog("Service: ОШИБКА: ${e.message}")
                    }
                }
            }
            ACTION_DISCONNECT -> stopVpn()
        }
        return START_STICKY
    }

    private fun stopVpn() {
        V2rayController.stopV2ray(this)
        stopForeground(true)
        stopSelf()
        LogManager.addLog("Service: Остановлен.")
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID).setContentTitle("DigroVPN").setSmallIcon(android.R.drawable.ic_lock_lock).setContentIntent(pi).setOngoing(true).build()
    }
}
