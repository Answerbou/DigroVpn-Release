package com.example.myvpn

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AdminActivity : AppCompatActivity() {
    private lateinit var tvLogs: TextView
    private lateinit var scrollLogs: ScrollView
    private val handler = Handler(Looper.getMainLooper())

    private val updateLogsRunnable = object : Runnable {
        override fun run() {
            tvLogs.text = LogManager.getLogs()
            scrollLogs.post { scrollLogs.fullScroll(ScrollView.FOCUS_DOWN) }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)
        tvLogs = findViewById(R.id.tvLogs)
        scrollLogs = findViewById(R.id.scrollLogs)
        LogManager.addLog("Admin: Панель открыта.")
        findViewById<Button>(R.id.btnClearLogs).setOnClickListener { LogManager.clear() }
        findViewById<Button>(R.id.btnForceStop).setOnClickListener { stopService(Intent(this, MyVpnService::class.java)); finish() }
    }

    override fun onResume() { super.onResume(); handler.post(updateLogsRunnable) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(updateLogsRunnable) }
}
