package com.example.myvpn
object LogManager {
    private val logs = mutableListOf<String>()
    fun addLog(message: String) {
        val time = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        logs.add("[$time] $message")
        if (logs.size > 50) logs.removeAt(0)
    }
    fun getLogs(): String = logs.joinToString("\n")
    fun clear() = logs.clear()
}
